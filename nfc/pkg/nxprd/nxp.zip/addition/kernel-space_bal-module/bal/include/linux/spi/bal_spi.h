/* linux/spi/bal_spi.h */

struct bal_spi_platform_data {
	int busy_pin;
};
